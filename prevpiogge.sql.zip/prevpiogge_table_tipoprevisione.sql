
-- --------------------------------------------------------

--
-- Struttura della tabella `tipoprevisione`
--

CREATE TABLE `tipoprevisione` (
  `id` int(11) NOT NULL,
  `previsione` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `tipoprevisione`
--

INSERT INTO `tipoprevisione` (`id`, `previsione`) VALUES
(0, 'No temporali'),
(1, 'Temporali sparsi'),
(2, 'Temporali diffusi');
