
--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `dettaglioprevisioni`
--
ALTER TABLE `dettaglioprevisioni`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `dettaglioprevisioni_ibfk_1` (`ID_previsione`),
  ADD KEY `dettaglioprevisioni_ibfk_2` (`ID_tipoprevisione`),
  ADD KEY `dettaglioprevisioni_ibfk_3` (`ID_fasciaoraria`);

--
-- Indici per le tabelle `fasciaorariaprevisione`
--
ALTER TABLE `fasciaorariaprevisione`
  ADD PRIMARY KEY (`ID`);

--
-- Indici per le tabelle `previsionieffettuate`
--
ALTER TABLE `previsionieffettuate`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `previsionieffettuate_ibfk_1` (`ID_utente`);

--
-- Indici per le tabelle `tipoprevisione`
--
ALTER TABLE `tipoprevisione`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `username_2` (`username`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `zone`
--
ALTER TABLE `zone`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `dettaglioprevisioni`
--
ALTER TABLE `dettaglioprevisioni`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12331;
--
-- AUTO_INCREMENT per la tabella `fasciaorariaprevisione`
--
ALTER TABLE `fasciaorariaprevisione`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT per la tabella `previsionieffettuate`
--
ALTER TABLE `previsionieffettuate`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=285;
--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT per la tabella `zone`
--
ALTER TABLE `zone`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `dettaglioprevisioni`
--
ALTER TABLE `dettaglioprevisioni`
  ADD CONSTRAINT `dettaglioprevisioni_ibfk_1` FOREIGN KEY (`ID_previsione`) REFERENCES `previsionieffettuate` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dettaglioprevisioni_ibfk_2` FOREIGN KEY (`ID_tipoprevisione`) REFERENCES `tipoprevisione` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dettaglioprevisioni_ibfk_3` FOREIGN KEY (`ID_fasciaoraria`) REFERENCES `fasciaorariaprevisione` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `previsionieffettuate`
--
ALTER TABLE `previsionieffettuate`
  ADD CONSTRAINT `previsionieffettuate_ibfk_1` FOREIGN KEY (`ID_utente`) REFERENCES `utenti` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
