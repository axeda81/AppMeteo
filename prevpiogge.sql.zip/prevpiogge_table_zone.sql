
-- --------------------------------------------------------

--
-- Struttura della tabella `zone`
--

CREATE TABLE `zone` (
  `ID` int(11) NOT NULL,
  `numZona` int(11) NOT NULL,
  `nomeZona` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabella con nomi e numeri identificativi delle 5 zone di allerta ';

--
-- Dump dei dati per la tabella `zone`
--

INSERT INTO `zone` (`ID`, `numZona`, `nomeZona`) VALUES
(1, 60, '60'),
(2, 61, '61'),
(3, 62, '62'),
(4, 63, '63'),
(5, 64, '64');
