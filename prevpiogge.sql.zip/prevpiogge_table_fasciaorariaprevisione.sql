
-- --------------------------------------------------------

--
-- Struttura della tabella `fasciaorariaprevisione`
--

CREATE TABLE `fasciaorariaprevisione` (
  `ID` int(11) NOT NULL,
  `fasciaoraria` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `fasciaorariaprevisione`
--

INSERT INTO `fasciaorariaprevisione` (`ID`, `fasciaoraria`) VALUES
(1, 'Oggi 12 - 15'),
(2, 'Oggi 15 - 18'),
(3, 'Oggi 18 - 21'),
(4, 'Oggi 21 - 24'),
(5, 'Domani 00 - 03'),
(6, 'Domani 03 - 06'),
(7, 'Domani 06 - 09'),
(8, 'Domani 09 - 12'),
(9, 'Domani 12 - 15'),
(10, 'Domani 15 - 18'),
(11, 'Domani 18 - 21'),
(12, 'Domani 21 - 24'),
(13, 'Oggi 12-18'),
(14, 'Oggi 18-24'),
(15, 'Domani 00-06'),
(16, 'Domani 06-12'),
(17, 'Domani 12-18'),
(18, 'Domani 18-24');
