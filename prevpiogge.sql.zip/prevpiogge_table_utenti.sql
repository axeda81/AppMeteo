
-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `ID` int(11) NOT NULL,
  `tipo` set('0','1','2') NOT NULL DEFAULT '0' COMMENT '0 = Meteo, 1 = Dirigente, 2 = Admin',
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`ID`, `tipo`, `nome`, `cognome`, `username`, `password`, `email`) VALUES
(12, '1', 'Maria Grazia', 'Pintus', 'dirigente', '3734fa4dbcff0a162f1737413ac7135c', 'mgpintus@arpa.sardegna.it'),
(21, '2', 'Chiara', 'Orru', 'chorru', '243a3b6f7ddfea2599743ce3370d5229', 'chorru@arpa.sardegna.it'),
(22, '0', 'Giacomo', 'Agrillo', 'gagrillo', '7905dc9b28a99ececfd6c31c0e9a6ccc', 'gagrillo@arpa.sardegna.it'),
(23, '0', 'Paolo', 'Boi', 'pboi', '976f0c87f1c58cd5238e76afb34caaab', 'pboi@arpa.sardegna.it'),
(24, '0', 'Carluccio', 'Castiglia', 'ccastiglia', '458fe03c78c4e6421b390094778086e2', 'ccastiglia@arpa.sardegna.it'),
(25, '0', 'Piero', 'Cau', 'pcau', '35abdf4355dd1af90beb1e027e0a2e1b', 'pcau@arpa.sardegna.it'),
(26, '0', 'Alessandro', 'Delitala', 'adelitala', 'aaf99b11826a10e452b601d17506c899', 'adelitala@arpa.sardegna.it'),
(27, '0', 'Carlo', 'Dessy', 'cdessy', '3d8e89acf5025e4a83ba1bc7f3159818', 'cdessy@arpa.sardegna.it'),
(28, '0', 'Gianni', 'Ficca', 'gficca', 'a6529e427d2df6ce21f5d00f02c9a06a', 'gficca@arpa.sardegna.it'),
(29, '0', 'Francesco', 'Nasir', 'fnasir', 'e3f461998f53cfbfde91733155047dc8', 'fnasir@arpa.sardegna.it'),
(30, '0', 'Salvatore', 'Natale', 'snatale', 'd6ae589bc0f3c336b2bb6301e7ba3d9b', 'snatale@arpa.sardegna.it'),
(31, '0', 'Paolo', 'Nicolosi', 'pnicolosi', '90366a3115239a4375d283d20e55142c', 'pnicolosi@arpa.sardegna.it'),
(32, '0', 'Samuele', 'Salis', 'ssalis', 'fd2c8796e92618edada2948e36efa5a9', 'ssalis@arpa.sardegna.it'),
(33, '0', 'Manuela', 'Idini', 'midini', '14eabc4f73631d2ad74fc377e347786b', 'midini@arpa.sardegna.it'),
(34, '0', 'Fabio', 'Petretto', 'fpetretto', '828285d3c7a63c1260ff09f5fedad0ee', 'fpetretto@arpa.sardegna.it'),
(35, '0', 'Alessandro', 'Serra', 'aserra', 'f9af799df6e090e5f6bc0975f5ae229e', 'aserra@arpa.sardegna.it'),
(36, '0', 'Sala Meteo', 'Sala Meteo', 'salameteo', 'b0dfa09a40946f554546f42e52740460', 'salameteo@email.com');
